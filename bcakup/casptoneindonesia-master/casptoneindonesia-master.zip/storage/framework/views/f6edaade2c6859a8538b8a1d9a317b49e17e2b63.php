<?php $__env->startSection('content'); ?>

<?php

$pelayanan = \App\Pelayanan::all();
?>
            <!-- Start service Area -->
            <section class="service-area section-gap" id="service">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12 pb-30 header-text text-center">
                            <h1 class="mb-10">Our Offered Services to you</h1>
                            <p>
                                Who are in extremely love with eco friendly system..
                            </p>
                        </div>
                    </div>                      
                    <div class="row">
                        <?php $__currentLoopData = $pelayanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="single-service">
                                <div class="thumb">
                                    <img src="<?php echo e(url('images/'.$key->gambar)); ?>" alt="" style="width: 350px; height: 200px;">                                   
                                </div>
                                <h4><?php echo e($key->judul); ?></h4>
                                <p>
                                    <?php echo e($key->keterangan); ?>

                                </p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                         
                    </div>
                </div>  
            </section>
            <!-- End service Area -->   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.industry', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>