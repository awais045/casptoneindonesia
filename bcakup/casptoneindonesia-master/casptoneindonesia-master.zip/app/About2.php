<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class About2 extends Model
{
    //
}
