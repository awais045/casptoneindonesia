<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class About2Controller extends Controller
{
    //
}
